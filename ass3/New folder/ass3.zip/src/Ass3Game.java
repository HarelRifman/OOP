public class Ass3Game {
    public static void main(String[] args) {
        Game game = new Game();
        game.initialize();
        game.run();
    }
}